class FormSchema {
  String invoiceNo;
  String startDate;
  String endDate;
  String from;
  String to;
  String companyName;
  String descriptionOfLoad;
  String driverName;
  String phoneNumber;
  String CBChannel;
  String trailer;
  String truck;
  String freightBill;
  String permitNo;

  int highPoleX;
  int hightPoleY;
  int highPoleResult;
  int leadMileX;
  int leadMileY;
  int leadMileResult;
  int overNightX;
  int overNightY;
  int overNightresult;
  int dayRateX;
  int dayRateY;
  int dayRateResult;
  int noGoX;
  int noGoY;
  int noGoResult;
  int detentionX;
  int detentionHour;
  int detentionY;
  int detentionResult;
  int chaseMilesX;
  int chaseMilesY;
  int chaseMilesResult;

  String escortDriver;
  String driver;
  String remarks;
}
