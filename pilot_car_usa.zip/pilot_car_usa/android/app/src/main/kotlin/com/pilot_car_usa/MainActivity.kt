package com.pilot_car_usa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
